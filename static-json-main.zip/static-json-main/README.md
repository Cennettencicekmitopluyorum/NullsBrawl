# static-json
[https://sourav9063.github.io/static-json/json/data.json](https://sourav9063.github.io/static-json/json/data.json)
